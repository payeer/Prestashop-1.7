<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{payeer}prestashop>payeer_e258fdafe003e9602f1bbff7de431b01'] = 'Payeer';
$_MODULE['<{payeer}prestashop>payeer_47e0d49db6d704469b44c38a9fe5d8a0'] = 'Оплата через Payeer';
$_MODULE['<{payeer}prestashop>payeer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Настройки обновлены';
$_MODULE['<{payeer}prestashop>payeer_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{payeer}prestashop>payeer_4825a5f07b97f1157ebb9a0b91c73417'] = 'URL мерчанта';
$_MODULE['<{payeer}prestashop>payeer_7f29d04821e39f71bb816705353fc163'] = 'URL- адрес для оплаты';
$_MODULE['<{payeer}prestashop>payeer_1bcfdc4388309d3cd580dc58c3c39034'] = 'Идентификатор магазина';
$_MODULE['<{payeer}prestashop>payeer_08302254171d4e8f6b8e3bbcc4f22155'] = 'Идентификатор магазина, зарегистрированного в системе Payeer';
$_MODULE['<{payeer}prestashop>payeer_952bf87c967660b7bbd4e1eb08cefc92'] = 'Секретный ключ';
$_MODULE['<{payeer}prestashop>payeer_d911c90fb6fc3635ef32263c8043fe8a'] = 'Секретный ключ мерчанта';
$_MODULE['<{payeer}prestashop>payeer_25e8a1e12a7509be6c4b307773806bbc'] = 'Фильтр IP';
$_MODULE['<{payeer}prestashop>payeer_04bed20b0c4574140e4f3ff2e7adce21'] = 'Список доверенных IP-адресов, вы можете указать маску';
$_MODULE['<{payeer}prestashop>payeer_ace7f2c128698c1354c81ab027942364'] = 'Путь к файлу журнала';
$_MODULE['<{payeer}prestashop>payeer_85e126ab453f47c2524b7683ae4b5128'] = 'Путь к файлу журнала для платежей через Payeer (например, /payeer_orders.log)';
$_MODULE['<{payeer}prestashop>payeer_6ceec431195d0070aa26c2eda69f68f0'] = 'Электронная почта для ошибок';
$_MODULE['<{payeer}prestashop>payeer_a1f5674fbf47e7f3d526622d07429564'] = 'Электронная почта для отправки ошибки оплаты';
$_MODULE['<{payeer}prestashop>payeer_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{payeer}prestashop>payeer_86d38d2a0eba3ac1373011c27bf27425'] = 'Информация для настройки магазина';
$_MODULE['<{payeer}prestashop>payeer_4a248da3df07d8b80a572649af38cec9'] = 'URL успешной оплаты';
$_MODULE['<{payeer}prestashop>payeer_9247a9dbab3f55add5d95422f165d6c7'] = 'URL-адрес, используемый для запроса в случае успешной оплаты.';
$_MODULE['<{payeer}prestashop>payeer_eff5520404cfa1852109ba28ac48b5ea'] = 'URL неуспешной оплаты';
$_MODULE['<{payeer}prestashop>payeer_8e5bf36dfb163d9347874dd2e018f586'] = 'URL-адрес, используемый для запроса в случае неудачного платежа';
$_MODULE['<{payeer}prestashop>payeer_c182e5e660af38e5c5b16fc10bf91565'] = 'URL обработчика';
$_MODULE['<{payeer}prestashop>payeer_55077fdc1e173cf7db5071e294bdcf19'] = 'Используется для уведомления об оплате.';
